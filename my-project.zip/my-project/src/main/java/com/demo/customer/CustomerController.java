package com.demo.customer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndView;

import com.demo.customer.entity.Customer;
import com.demo.customer.entity.CustomerLogs;

@Controller
public class CustomerController {
	@Autowired
	CustomerLogsRepository logsrepo;
	
	@Autowired
	CustomerRepository repo;
	
	@RequestMapping(path = "/customer", method = RequestMethod.GET)
	public String getMainPage(Model model) {
		CustomerLogs c = new CustomerLogs();
		Customer c_ = new Customer();
		model.addAttribute("CustomerLogs", c);
		model.addAttribute("Customer", c_);
		return "customer";
	}
	
	@RequestMapping(path = "/customer", method = RequestMethod.POST)
	public ModelAndView processForm(@ModelAttribute("CustomerLogs") CustomerLogs c) {
		ModelAndView mv = new ModelAndView();
		System.out.println("i got activated!");
		Customer probe = new Customer();
		probe.setEmail(c.getEmail());
		Example<Customer> example = Example.of(probe, ExampleMatcher.matchingAny());
		boolean exists = repo.exists(example);
		if(exists == false) {
			System.out.println("email not found");
			
			mv.setViewName("customerRegister");
			mv.addObject(new Customer(c.getEmail(),""));
//			getMainPage();
		}else {
			System.out.println("email found bro");
			
			mv.setViewName("final");
			mv.addObject("email", c.getEmail());
			mv.addObject("problemDescription", c.getProblemDescription());

//			getMainPage();
		}
		return mv;
	}
	
//	@RequestMapping(path = "/final", method = RequestMethod.POST)
//	public ModelAndView displayConfirmationPage() {
//		
//	}
	
//	@RequestMapping(path = "/customer", method = RequestMethod.POST)
//	public void checkAndReturnResponse(@ModelAttribute("request") Customer c) {
//		
//	}
}
